import * as React from 'react';
import { IRegistroVehiculo } from './IDataFiltrosProps';

interface Props {
  data: IRegistroVehiculo[];
  onFiltrar: (filtros: { marca?: string }) => void;
  filtrosActivos: { marca?: string };
}

const Filtros: React.FC<Props> = ({ data, onFiltrar, filtrosActivos }) => {
  const marcasUnicas = Array.from(new Set(data.map(d => d.marca)));

  return (
    <div>
      <label>Marca:</label>
      <select
        value={filtrosActivos.marca || ''}
        onChange={(e) => onFiltrar({ marca: e.target.value || undefined })}
      >
        <option value="">-- Todas --</option>
        {marcasUnicas.map((marca, i) => (
          <option key={i} value={marca}>{marca}</option>
        ))}
      </select>
    </div>
  );
};

export default Filtros;
