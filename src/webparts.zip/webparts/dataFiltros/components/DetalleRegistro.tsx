import * as React from 'react';
import { IRegistroVehiculo } from './DataFiltros';

interface Props {
  registro: IRegistroVehiculo;
}

const DetalleRegistro: React.FC<Props> = ({ registro }) => {
  return (
    <div>
      <h3>Detalle del Vehículo</h3>

      <p><strong>Placa:</strong> {registro.placa}</p>
      <p><strong>Marca:</strong> {registro.marca}</p>
      <p><strong>Propietario:</strong> {registro.propietario}</p>
      <p><strong>Hora de Entrada:</strong> {registro.hora_entrada}</p>
      <p><strong>Hora de Salida:</strong> {registro.hora_salida}</p>
      <p><strong>Duración:</strong> {registro.duracion}</p>

      <h4>Archivos adjuntos</h4>
      {registro.attachments.length > 0 ? (
        <ul>
          {registro.attachments.map((file, idx) => (
            <li key={idx}>
              <a href={file.serverRelativeUrl} target="_blank" rel="noopener noreferrer">
                {file.fileName}
              </a>
            </li>
          ))}
        </ul>
      ) : (
        <p>No hay archivos adjuntos.</p>
      )}
    </div>
  );
};

export default DetalleRegistro;
