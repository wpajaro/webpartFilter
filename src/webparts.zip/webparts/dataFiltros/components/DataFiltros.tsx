import * as React from 'react';
import { useEffect, useState } from 'react';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { getSP } from '../../pnpjsConfig';
import Filtros from './Filtros';
import DetalleRegistro from './DetalleRegistro';
import { IRegistroVehiculo } from './IDataFiltrosProps';

import styles from './DataFiltros.module.scss';

interface IDataFiltrosProps {
  context: WebPartContext
}

const DataFiltros: React.FC<IDataFiltrosProps> = ({ context }) => {


//const VisualizadorVehiculos: React.FC = () => {
  const [registros, setRegistros] = useState<IRegistroVehiculo[]>([]);
  const [filtros, setFiltros] = useState<{ marca?: string }>({});
  const [registroSeleccionado, setRegistroSeleccionado] = useState<IRegistroVehiculo | null>(null);

  const cargarDatos = async (): Promise<void> => {
    try {
      const sp = getSP();

      const items = await sp.web.lists.getByTitle("tabla_v_prueba").items
        .select("ID", "placa", "marca", "propietario", "hora_entrada", "hora_salida", "duracion")
        .top(100)();

      const registrosConAdjuntos = await Promise.all(
        items.map(async (item: {
          ID: number;
          placa: string;
          marca: string;
          propietario: string;
          hora_entrada: string;
          hora_salida: string;
          duracion: string;
        }) => {
          const attachments = await sp.web.lists.getByTitle("tabla_v_prueba").items.getById(item.ID).attachmentFiles();
          return {
            ID: item.ID,
            placa: item.placa,
            marca: item.marca,
            propietario: item.propietario,
            hora_entrada: item.hora_entrada,
            hora_salida: item.hora_salida,
            duracion: item.duracion,
            attachments: attachments.map((file: { FileName: string; ServerRelativeUrl: string }) => ({
              fileName: file.FileName,
              serverRelativeUrl: file.ServerRelativeUrl,
            }))
          };
        })
      );


      setRegistros(registrosConAdjuntos);
    } catch (error) {
      console.error("Error al cargar los registros:", error);
    }
  };

    useEffect(() => {
    void cargarDatos();
  }, []);

  const registrosFiltrados = registros.filter(r =>
    !filtros.marca || r.marca === filtros.marca
  );

  return (
    <div className={styles.panelContainer}>
      <div className={styles.filtros}>
        <h3>Filtros</h3>
        <Filtros data={registros} filtrosActivos={filtros} onFiltrar={setFiltros} />
        <ul>
          {registrosFiltrados.map(item => (
            <li key={item.ID} onClick={() => setRegistroSeleccionado(item)} style={{ cursor: 'pointer', marginBottom: 8 }}>
              {item.placa} - {item.marca}
            </li>
          ))}
        </ul>
      </div>
      <div className={styles.detalle}>
        {registroSeleccionado ? (
          <DetalleRegistro registro={registroSeleccionado} />
        ) : (
          <p>Selecciona un registro para ver el detalle.</p>
        )}
      </div>
    </div>
  );
};

export default DataFiltros;
