
require("./DataFiltros.module.css");
const styles = {
  panelContainer: 'panelContainer_c8ae134e',
  filtros: 'filtros_c8ae134e',
  detalle: 'detalle_c8ae134e'
};

export default styles;
